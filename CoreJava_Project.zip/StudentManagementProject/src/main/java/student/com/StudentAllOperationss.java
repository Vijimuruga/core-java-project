package student.com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



public class StudentAllOperationss {
	private static Connection connection;
	private static Scanner sc;
	private static ResultSet rs;
	private static PreparedStatement pst;
	private static int id;
	private static  String name,emailid,phone,sel,sel1,sel2,sel3;
	
	
	private static int cid;
	private static  String cname,cfee;
	
	public static void displayRecord() throws SQLException {
		connection=DatabaseConnection.getConnection();
	
		
		while(true) {
		    System.out.println("Enter");
			System.out.println("1.To Display Courses ");
			System.out.println("2.To Display Student Details");
			System.out.println("----------------------------------------------------");
			sc=new Scanner(System.in);
			int choi=sc.nextInt();
		switch(choi) {
		case 1:
			
				String sel3="select * from courses";
				pst = connection.prepareStatement(sel3);
				rs=pst.executeQuery();

				System.out.println("===========COURSE DETAILS============");
				System.out.println();
				System.out.println("CID\tCNAME\t\tCFEE");
				
				while(rs.next()) {
					
				
					System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t\t"+rs.getString(3));
				}
			break;
			case 2:
			

				String sel="select * from student";
				
				pst = connection.prepareStatement(sel);
				rs=pst.executeQuery();

				System.out.println("===========STUDENT DETAILS============");
				System.out.println();
              
				System.out.println("SID\tSNAME\t\tSEmail\t\t\tSPHONE\t\t\tCourseId");
				while(rs.next()) {
					System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t\t"+rs.getString(3)+"\t\t"+rs.getString(4)+"\t\t"+rs.getInt(5));
				}
				break;
			default : System.out.println("Invalid input");
            
		}
		
		System.out.println();
		System.out.println("Do you want to contine to Display Record again y/n");
		char choice=sc.next().toLowerCase().charAt(0);
		if(choice!='y') {
			break;
		}
		}
    
		
	}
		
	


	public static void addRecord() throws SQLException {
		
		connection = DatabaseConnection.getConnection(); //getting connection
		
	
		
		//adding record accept , sid, and sname
		sc = new Scanner(System.in);
		
		System.out.println("Enter student id");
		id = sc.nextInt();
		System.out.println("Enter name");
		name = sc.next();
		System.out.println("Enter student emailid");
		emailid = sc.next();
		System.out.println("Enter student phone");
		phone = sc.next();
		System.out.println("Enter course id");
		cid = sc.nextInt();
		
		//check sid exists or not
		
		
		sel = "select * from student where sid=?";
		
		pst = connection.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery(); //selection use executeQuery
		
		//to check id exists or not
		if(!rs.next()) { //if record is not there then go for insert
			String ins = "insert into student values(?,?,?,?,?)";
			//String ins = "insert into student values("+id+",'"+name+"')";
			pst = connection.prepareStatement(ins);
			pst.setInt(1, id);
			pst.setString(2, name);
			pst.setString(3, emailid);
			pst.setString(4, phone);
			pst.setInt(5, cid);
			int retval = pst.executeUpdate(); //for insert , update , delete use executeUpdate
			if(retval>0) {
				System.out.println("Record inserted");
			}else {
				System.out.println("Error occured");
			}
	}
		else {
			System.out.println(id+" already exists ");
		}
		
		
		
		
		
	}
	
	
	public static void updateRecord()throws SQLException {  
		connection = DatabaseConnection.getConnection();
		
		System.out.println("*********enter your choice*********");
		System.out.println("1.Update Student Name");
		System.out.println("2.Update Student email");
		System.out.println("3.Update Student Phone No");
		
		
		sc=new Scanner(System.in);
		int choice=sc.nextInt();
		
		switch(choice) {
		case 1:
		
		
		System.out.println("Enter the name to change");
		name = sc.next();
		System.out.println("Enter id");
		id = sc.nextInt();
		
		sel = "select * from student where sid=?";
		pst = connection.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		
		if(rs.next()) { //if record exists returns true
			String upd ="update student set sname=? where sid=?";
			pst = connection.prepareStatement(upd);
			pst.setString(1, name);
			pst.setInt(2, id);
			int retval=pst.executeUpdate();
			
			if(retval > 0) {
				System.out.println("Recorded is updated ");
			}else {
				System.out.println("Error occurred");
			}
			
		}else {
			System.out.println("Record not exists");
		}
		break;
		}
		switch(choice) {
		case 2:
		
		
		System.out.println("Enter the email to change");
		emailid = sc.next();
		System.out.println("Enter id");
		id = sc.nextInt();
		
		sel1 = "select * from student where sid=?";
		pst = connection.prepareStatement(sel1);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		
		if(rs.next()) { //if record exists returns true
			String upd ="update student set semail=? where sid=?";
			pst = connection.prepareStatement(upd);
			pst.setString(1, emailid);
			pst.setInt(2, id);
			int retval=pst.executeUpdate();
			
			if(retval > 0) {
				System.out.println("Recorded is updated ");
			}else {
				System.out.println("Error occurred");
			}
			
		}else {
			System.out.println("Record not exists");
		}
		break;
		
		}
		switch(choice) {
		case 3:
		
		
		System.out.println("Enter the phone No to change");
		phone = sc.next();
		System.out.println("Enter id");
		id = sc.nextInt();
		
		sel2 = "select * from student where sid=?";
		pst = connection.prepareStatement(sel2);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		
		if(rs.next()) { //if record exists returns true
			String upd ="update student set sphone=? where sid=?";
			pst = connection.prepareStatement(upd);
			pst.setString(1, phone);
			pst.setInt(2, id);
			int retval=pst.executeUpdate();
			
			if(retval > 0) {
				System.out.println("Recorded is updated ");
			}else {
				System.out.println("Error occurred");
			}
			
		}else {
			System.out.println("Record not exists");
		}
	
		}	
		
	}
	public static void deleteRecord() throws SQLException {
		//delete record (if record exists)

		System.out.println("Before Deletion");
		displayRecord();
		connection = DatabaseConnection.getConnection();
		sc = new Scanner(System.in);
		System.out.println("Enter id");
		id= sc.nextInt();
		
		sel = "select * from student where sid=?";
		pst = connection.prepareStatement(sel);
		pst.setInt(1, id);
		rs = pst.executeQuery();
		
		if(rs.next()) {
			String del = "delete from student where sid=?";
			pst = connection.prepareStatement(del);
			pst.setInt(1, id);
			int retval=pst.executeUpdate();
			if(retval>0) {
				System.out.println("Record is deleted");
				System.out.println("After deleteion");
				displayRecord();
				
			}else {
				System.out.println("Error occurred");
			}
		}else {
			System.out.println(id+" not exists");
		}
		
	}
		}
			

		