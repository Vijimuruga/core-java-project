package student.com;

import java.sql.SQLException;
import java.util.Scanner;



public class StudentMain {

	public static void main(String[] args) throws SQLException {
		 
		
		Scanner sc = new Scanner(System.in);
		System.out.println("*************STUDENT MANAGEMENT SYSTEM***************");
		System.out.println();
		
		
		while(true) {
		System.out.println("Enter");
		System.out.println("----------------------------------------------------");
		System.out.println("1. Display Record");
		System.out.println("2. Add new Record");
		System.out.println("3. Update record");
		System.out.println("4. Delete record based on id");
		int ch=sc.nextInt();
		
		switch(ch) {
		
		case 1: StudentAllOperationss.displayRecord();
		         break;
		case 2: StudentAllOperationss.addRecord();
		          break;
		case 3:  StudentAllOperationss.updateRecord();
		         break;
		case 4:  StudentAllOperationss.deleteRecord();
		         break;
		default : System.out.println("Invalid input");
		            
		}
		
		System.out.println();
		System.out.println("Do you want to contine to Main RECORDS  y/n");
		char choice=sc.next().toLowerCase().charAt(0);
		if(choice!='y') {
			break;
		}
		}
		System.out.println("Program is terminated");
    }

}

